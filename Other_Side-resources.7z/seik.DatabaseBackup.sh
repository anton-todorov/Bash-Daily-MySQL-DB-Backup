#!/bin/bash

# Shell script to backup mysql databases. 
# Edited by Anton Todorov, <anton.todorov89@gmail.com>.
# Backs up all tables of all databases on a specified host to sql files, (can be gzipped if needed).  
# One backup per datestamp, so if you run the script ten times in one day, it will create ten different backups for that day. 
# You can also exclude some databases from backup.  Version 2.0 11/13/2014.

# It is not necessary, but you can run as root!  A function to check for root should probably be added here.

# Defining username, password and hostname
MyUSER="backup"				# MySQL username
MyPASS="pass"				# MySQL password. Use if the user have password
#MyHOST="192.168.2.201"		# MySQL hostname or IP
#MyHOST="192.168.190.10"	# MySQL hostname or IP
MyHOST="127.0.0.1"			#MyHOST IP

# Paths to binaries, hardcode these if they can't be autodetected via the 'which' command.
# For Mac OS X, either hardcode these paths or add /usr/local/bin/mysql/bin to root's $PATH.

keep_backups_number=5

MYSQL="/usr/local/mysql/bin/mysql"
MYSQLDUMP="/usr/local/mysql/bin/mysqldump"
GZIP="$(which gzip)"

# Path to the Main directory where all backups will be stored.
DEST="Volumes/SSD/Users/antontodorov/Desktop/MYSQL_BACKUPS"
test ! -d "/$DEST" && echo "$(date) : missing destination directory ${DEST}" && exit 1
cd "/$DEST" # Change the current directory to the destination directory where all backups will be stored.

# clean all but the latest $keep_backups_number directories here 
ls -rt | tail -n +${keep_backups_number} | \
while read to_delete; \
do test -d ${to_delete} && echo "$(date) : deleting directory ${to_delete}" && rm -rvf ${to_delete}; \
done

WEEK="$(($(date +"%W")+1))" # Variable for week number. %W(Monday start, 00-53), %U(Sunday start, 00-53), %V(ISO, Monday start, 01-53)

# Name of the Main Backup Directory where all backup will be stored.
MBD="Week #$WEEK"

# Check if the main backup directory exists and create it if not.
[ ! -d "$MBD" ] && mkdir -p "$MBD" || :

	# Check if an old directory exist and delete if so.
	OLDDIR="$(($WEEK-2))" # Variable for 'Week-2' number.
	
	# Name of the old directory which will be deleted.
	OLDMBD="Week #$OLDDIR"
	
	# Check if old directory exists and delete it.
	[ -d "$OLDMBD" ] && rm -rf "$OLDMBD" || :
	
# seikath 		
# 		# Check if 'Week #3' directories exist and delete the last few directories from the last year.
# 		[ -d "Week #3" ] && rm -rf "Week #50" && rm -rf "Week #51" && rm -rf "Week #52" && rm -rf "Week #53" || :
	
cd "/$DEST/$MBD" # Change the current directory to the Main directory for backups.

# Check if a directory with a name of the host exists and create it if not.
[ ! -d "$MyHOST" ] && mkdir -p "$MyHOST" || :

CHOWN 0.0 -R $MyHOST
CHMOD 0070 $MyHOST

# Define today's date.
NOW="$(date +"%Y.%m.%d_%Hh%Mm%Ss")"
cd "/$DEST/$MBD/$MyHOST" #Change the current directory to the directory with the host name.

# Check if specific directory named with the current time exists and create it if not.
[ ! -d "$NOW" ] && mkdir -p "$NOW" || :

cd "$NOW" #Change the current directory to the directory with the current time name.

LOGFILENAME="[error_log]$NOW.txt"

# Looping the databases in the defined host
for db in `$MYSQL -u $MyUSER -h $MyHOST -p$MyPASS -Bse 'show databases' | grep -Ev '(Database|information_schema|performance_schema|mysql)'`; 
do

echo "== = --- = == Now running in database $db == = --- = =="
	# seikath add lock here	
	test -d /tmp/${0}.${db}.lock && echo "$(date) : /tmp/${0}.lock directory existing, skipping the backup for db ${db}" && continue
	mkdir /tmp/${0}.${db}.lock
	# Looping the tables in the databases of the host
	for tb in `$MYSQL -u $MyUSER -h $MyHOST -p$MyPASS $db -e 'show tables' | grep -v '^Tables_in_'`; # Use if the user does have password.
	do
	# seikath check openeed tables and skip them if they are opened for more thatn 60 seconds
	wait=0
	while $wait -le 60
	do
		check_open_tables=$(${MYSQL} -NB -u $MyUSER -h $MyHOST -p$MyPASS -e "show open tables where in_use=1;" | grep -i $db | grep -i $tb | wc -l)
		test $check_open_tables -eq 0 && echo "$(date) : the table ${$db}.$tb is locked now, skipping it" && break
		echo "$(date) : sleeping 1 second waiting for ${$db}.$tb to be closed" && sleep 1 
		((wait++))
	done
	test $check_open_tables -gt 0 && echo "$(date) : the table ${$db}.$tb is locked now, skipping it" && continue

	echo "$(date) : --== Now Dumping Table $tb from database ${$db} ==--"
	
	OUTPUTFILENAME="$db-$tb".sql # Variable output file name.
	$command="$MYSQLDUMP --single-transaction --force --quick --compact --lock-tables=false --log-error=$LOGFILENAME -u $MyUSER -h $MyHOST -p$MyPASS $db $tb > $OUTPUTFILENAME"
	${command} 
	test $? -gt 0 && echo "$(date) : command ${command} failed"
	#$GZIP -c $OUTPUTFILENAME > $OUTPUTFILENAME.gz && rm $OUTPUTFILENAME # Use if needed to GZIP every table
	
	[ ! -s $LOGFILENAME ] && rm $LOGFILENAME || : #If log.txt is empty delete it
	[ -f "$LOGFILENAME" ] && less -FX $LOGFILENAME || : # If a log.txt file exist, display the content of the log.txt file. 
	
	done

done




#$GZIP -r  DIR

#sudo /usr/local/mysql/support-files/mysql.server restart # To restart the MySQL

#killall Terminal # Command to kill all Terminal windows.

#sleep 5 # Delay of 5 seconds

# All done now.  ;o]P~~~

###########################
###### DEBUGGING HELP #####
###########################
##Check if 'var' is empty #
#if [ -n "$var" ]; then   #
#    echo "not empty"     #
#else                     #
#    echo "empty"         #
#fi                       #
###########################

####################  Credits ######################
# Original by Leaman Crews, <leamanc@gmail.com>    #
####################################################